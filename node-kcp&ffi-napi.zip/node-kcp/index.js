module.exports = require('./build/Release/kcp');
